<?php
// Zenphoto theme definition file
$theme_description['name'] = 'cimi';
$theme_description['author'] = 'Pim Rijpsma';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>