<?php
// Zenphoto theme definition file
$theme_description['name'] = 'samuel2';
$theme_description['author'] = 'Ben Wilson';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>