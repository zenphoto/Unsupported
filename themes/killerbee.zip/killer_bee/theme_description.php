<?php
// Zenphoto theme definition file
$theme_description['name'] = 'killer_bee';
$theme_description['author'] = 'Jason Hsu';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>