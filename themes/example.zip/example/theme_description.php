<?php
// Zenphoto theme definition file
$theme_description['name'] = 'Example Theme';
$theme_description['author'] = 'Tristan Harward';
$theme_description['version'] = '1.2.6';
$theme_description['date'] = '11/05/2007';
$theme_description['desc'] = gettext("This theme was designed to show off many of ZenPhoto's features. It includes many template tags and doesn't look half bad. Also a great example if you want to make your own theme or integrate ZenPhoto into a blog.");
?>