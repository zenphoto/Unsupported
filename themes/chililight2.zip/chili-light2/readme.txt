Chili-Light_Official Theme

This theme has the default layout and Lightbox.js v.2 integration.

Installation:
Unpack to your zenphoto theme directory
Go to your admin panel and activate it.

All should work.


~ChiliFrei64
http://www.chilifrei.net