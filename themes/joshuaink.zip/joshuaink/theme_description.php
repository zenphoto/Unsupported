<?php
// Zenphoto theme definition file
$theme_description['name'] = 'joshuaink';
$theme_description['author'] = '<a href="http://www.darrelldudics.com/" target="_blank">Darrell Dudics</a>';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>