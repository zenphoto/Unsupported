<?php
// Zenphoto theme definition file
$theme_description['name'] = 'moonlover';
$theme_description['author'] = '<a href="http://www.tanarat.com/blogs/" target="_blank">Tanarat Terkthaw (Artz)</a>';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>