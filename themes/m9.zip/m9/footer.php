<div id="footer"><p>
	<a href="http://zenphoto.org/">Zenphoto</a> &amp; <a href="http://michalrusina.sk/galeria/page/m9/">M9</a> by <a href="http://michalrusina.sk/">michalrusina.sk</a>.
</p></div>
