﻿<?php
$theme_description['name'] = 'ZP-M9';
$theme_description['author'] = '<a href="http://www.michalrusina.sk/" target="_blank">Michal Rusina</a>';
$theme_description['version'] = '2.0';
$theme_description['date'] = '29.10.9';
$theme_description['desc'] = 'Simple theme with neutral colors and CSS3 enhacements.';
?>