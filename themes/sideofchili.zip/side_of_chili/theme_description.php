<?php
// Zenphoto theme definition file
$theme_description['name'] = 'side of chili';
$theme_description['author'] = '<a href="http://www.chilifrei.net" target="_blank">Daniel Frei (Chilifrei64)</a>';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>