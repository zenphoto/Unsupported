<?php
// Zenphoto theme definition file
$theme_description['name'] = 'ensellitisZEN';
$theme_description['author'] = '<a href="http://www.noscope.com" target="_blank">Joen Asmussen</a>';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>