<?php
// Zenphoto theme definition file
$theme_description['name'] = 'thatlittleguy';
$theme_description['author'] = 'David Wehrs';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = '';
?>