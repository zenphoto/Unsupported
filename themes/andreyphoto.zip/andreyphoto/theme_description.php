<?php
// Zenphoto theme definition file
$theme_description['name'] = 'andreyphoto';
$theme_description['author'] = '<a href="http://www.andreyphoto.com/" target="_blank">Andrey Samode</a>';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "";
?>