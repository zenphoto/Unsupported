<?php
// Zenphoto theme definition file
$theme_description['name'] = 'simple plus';
$theme_description['author'] = 'Nils K. Windisch';
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = '';
?>