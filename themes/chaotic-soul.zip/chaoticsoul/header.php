<div id="header">
	<h1><a href="<?php echo htmlspecialchars(getGalleryIndexURL());?>" title="<?php echo gettext('Albums Index'); ?>">Chaotic <span>soul</span></a></h1>
	<div class="description"><?php /* bloginfo('description'); */ ?></div>
</div>

<hr />

<div id="headerimg" class="clearfix">
	<div class="image bkgleft"> </div>
	<div class="image bkgright"> </div>
</div>
<hr />