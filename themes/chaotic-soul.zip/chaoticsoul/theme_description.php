<?php
// Zenphoto theme definition file
$theme_description['name'] = 'chaoticsoul';
$theme_description['author'] = gettext('Richard Castellanos, modified by Benjamin Swatek.');
$theme_description['version'] = true;
$theme_description['date'] = true;
$theme_description['desc'] = "Chaotic Soul adaptation for Zenphoto";
?>